<?php
require_once(__DIR__ . '/vendor/autoload.php');

use \RollingCurl\RollingCurl;

$rollingCurl = new \RollingCurl\RollingCurl();

$list     = explode("\n", str_replace("\r", "", file_get_contents('list.txt')));
foreach ($list as $key => $mp) {

  if (empty($mp)) { continue; }

  $rollingCurl->get('http://localhost:109?empas=' . $mp);
}

$rollingCurl
    ->setCallback(function(\RollingCurl\Request $request, \RollingCurl\RollingCurl $rollingCurl) use (&$results) {
      echo $request->getResponseText();
    })
    ->setSimultaneousLimit(50)
    ->execute();
;
